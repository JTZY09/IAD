import base64
import openai

# Function to process images and convert them to base64
def process_images(image_files):
    base64_frames = []
    for image_file in image_files:
        with open(image_file, "rb") as img_file:
            base64_encoded = base64.b64encode(img_file.read()).decode('utf-8')
            base64_frames.append(base64_encoded)
    return base64_frames
 
# List of image file paths to analyze
image_files = ["boxes.jpg"]  # Add your image paths
 
# Process images to base64 frames
base64Frames = process_images(image_files)
openai.api_key = "sk-proj-cUvQC7boOawIjn1sD8J9T3BlbkFJpjQbvm47igbN5F8iu5kr"
cont = True
first = False
k = 2
messages=[{"role": "system", "content": "You are in a virtual box world where six boxes are labeled with numbers from 1 to 6."}]
for i in range(1):
        # Add new image filenames dynamically
        #new_image = "boxes" + str(k) + ".jpg"
        new_image=[image_files]
        #image_files.append(new_image)
               
        # Process the new image and convert it to base64
        base64Frames = process_images(image_files)  # Process only the new image
                      
        # Append the previous assistant's response
        #messages.append({"role": "assistant", "content": response_content})
        
        # Add the second user message and new image
        #if i==0:
        new_message= {"role": "user","content":[ """I provided to you image of six boxes othat are labeled with numbers from 1 to 6 and ordered in 3 lists. 
                       
                        1. Analyse carefully provided image and detect ALL boxes and their position in Lists./n
                        ***IMPORTANT:*** <<<BOTTOM BOX IS ALWAYS FIRST ELEMENT OF THE LIST.>>>/n
                        In your response provide initial state of the lists following given format./n
                        EXAMPLE of response format: /n
                        List1=[1,2]/n
                        List2=[5,6]/n
                        List3=[3]/n
                        ListF1=[4]/n
                        ListF2=[]/n
                              """, 
                        
                        *map(lambda x: {"type": "image_url",
                            "image_url": {"url": f'data:image/jpg;base64,{x}', "detail": "low"}}, base64Frames)
                        ]}

       
        messages.append(new_message)
            #print(len(messages))
            #print(messages)

            # Make the API request
        response = openai.ChatCompletion.create(
                model="gpt-4o",
                messages=messages,
                temperature=0.3,
                #top_p=0.9,         # Nucleus sampling (only considers tokens with cumulative probability of 0.9)
                
            )
        response_content = response['choices'][0]['message']['content']
        print(response_content)
        # Step 1: Parse the string to extract lists
lines = response_content.strip().split('\n')
lines = response_content.strip().split('\n')
lists_dict = {}

for line in lines:
    line = line.strip()  # Remove extra spaces

    # Only process lines that contain an '=' sign
    if '=' in line:
        name, value = line.split('=', 1)  # Split on the first '=' only
        name = name.strip()  # Remove extra spaces from name
        value = value.strip().rstrip('/n').lstrip()  # Clean value string

        # Convert the string representation of the list into an actual list
        if value == '[]':
            lists_dict[name] = []
        else:
            lists_dict[name] = eval(value)  # Use eval with caution

# Step 2: Replace the initial lists with the parsed lists
List1 = lists_dict.get('List1', [])
List2 = lists_dict.get('List2', [])
List3 = lists_dict.get('List3', [])
ListF1 = lists_dict.get('ListF1', [])
ListF2 = lists_dict.get('ListF2', [])

# Group all lists together for easier access
all_lists = [List1, List2, List3, ListF1, ListF2]
list_of_steps=[]
max_number = 7
# Function to print the current state of all lists
def print_lists_state():
    print("Current state of all lists:")
    for i, lst in enumerate(all_lists):
        print(f"List {i + 1}: {lst}")
    print()  # Print a newline for better readability

# Print initial state of all lists
print("Initial lists:")
print_lists_state()

initial_ordered_list = None
for index, lst in enumerate(all_lists):
    if lst == [1, 2] or lst == [1, 2, 3]:  # Check for specific structures
        initial_ordered_list = lst
        oindex=index

        break

# Set target number and final list based on the initial check
if initial_ordered_list:
    
    if initial_ordered_list[-1]==2:
        target_number = 3
    if initial_ordered_list[-1]==3:
        target_number = 4
    print(f"Found an ordered list: {initial_ordered_list}. Setting first target number to {target_number}")
    final_list = all_lists[oindex]
    #initial_ordered_list.copy()  # Start with the ordered list
else:
    target_number = 1  # Default starting point if no ordered list is found
    #final_list = []    # Initialize final list

print("Starting the sorting process...\n")

# Process for numbers 1 to 6
first = True
for target_number in range(target_number, max_number):
    print(f"Processing target number: {target_number}")
    for index, lst in enumerate(all_lists):
        if target_number in lst:
            list_index = index  # Store the index of the list
            target_list = all_lists[list_index]  # Get the target list
            print(f"Found {target_number} in List {list_index + 1}: {target_list}")
            break
    else:
        print(f"{target_number} not found in any list.")
        continue  # Skip to the next target_number if not found

    # Check if the target number is available for popping
    while target_list:
        item = target_list[-1]  # Get the last element of the target list
        print(f"Current item to process: {item}")

        if item == target_number:
            print(f"Item {item} matches target number.")
            if item == 1:
                if len(target_list) == 1:
                    final_list = target_list
                    print(f"Final list for number {item} is: {final_list}")
                    print_lists_state()
                    break
                else:
                    for index, lst in enumerate(all_lists):
                        if len(lst) == 0:  # Check if the current list is empty
                            print(f"Popping {item} from List {list_index + 1} and appending to List  {index +1}")
                            list_of_steps.append((item, "L"+str(index+1)))
                            target_list.pop()
                            lst.append(item)  # Append the item to the first empty list
                            final_list = lst
                            print_lists_state()
                            break  # Exit the loop after finding the first empty list
                break    
            else:
                print(f"Popping {item} from List {list_index + 1} and adding to final list.")
                list_of_steps.append((item, item-1))
                target_list.pop()
                final_list.append(item)
                print_lists_state()
                break
        else:
            print(f"Item {item} does not match target number. Popping it.")
            target_list.pop()
            append_item = False
            for index, lst in enumerate(all_lists):
                if len(lst) == 0:  # Check if the current list is empty
                    lst.append(item)  # Append the item to the first empty list
                    print(f"Popped {item} from List {list_index + 1} and appended to List {index + 1}")
                    list_of_steps.append((item, "L"+str(index+1)))
                    append_item = True
                    print_lists_state()  # Print the state of all lists after append
                    break  # Exit the loop after finding the first empty list
               
            if not append_item:
                for index, lst in enumerate(all_lists):
                    if lst[-1] == item -1: # target_number and lst[-1]!= item:
                        lst.append(item)  # Append the item to the first empty list
                        print(f"Popped {item} from List {list_index + 1} and appended to List {index + 1}")
                        list_of_steps.append((item, "L"+str(index+1)))
                        print_lists_state()  # Print the state of all lists after append
                        break  # Exit the loop after finding the first empty list
                    
# Final output
print("Final state of all lists:")
print_lists_state()  # Print the state of all lists after append
print(list_of_steps)