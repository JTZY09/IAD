import cv2

def capture(camera_index=1, width=1280, height=720, save_path="boxes.jpg"):
    cap = cv2.VideoCapture(camera_index)
    cap.set(3, width)
    cap.set(6, height)

    if not cap.isOpened():
        print("Can't open camera")
        exit()

    while True:
        ret, frame = cap.read()

        if ret:
            cv2.imshow("Frame", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('s'):  # Capture
                cv2.imwrite(save_path, frame)
                print(f"Image saved successfully at {save_path}!")
            elif key == ord('q'):  # Exit
                break
        else:
            print("Cannot capture image.")
            break

    cap.release()
    cv2.destroyAllWindows()

# Example usage
capture()
