from detection import detect_square
import DobotDllType as dType
import numpy as np
import csv

# Dobot connection
api = dType.load()
dType.ConnectDobot(api, "COM3", 115200)[0]
dType.SetQueuedCmdClear(api)

# Upper left detection
C1 = []
print('Put the object on the upper left corner, and robot arm out of view.')
input('Enter when done')
# coords = detect_square()
coords = (494, 313)
print(f"C1: {coords}")
C1.append(coords[0])
C1.append(coords[1])

print('Put the sucker on the box at the upper left corner')
input('Enter when done')
current_pose = dType.GetPose(api)
print(f"D1: {current_pose}")
D1 = [current_pose[0], current_pose[1], -26]
print('x, y, z', D1)

# Lower right detection
C2 = []
print('Put the object on the lower right corner, and robot arm out of view.')
input('Enter when done')
# coords = detect_square()
coords = (687, 564)
print(f"C2: {coords}")
C2.append(coords[0])
C2.append(coords[1])

print('Put the sucker on the box at the lower right corner')
input('Enter when done')
current_pose = dType.GetPose(api)
print(f"D2: {current_pose}")
D2 = [current_pose[0], current_pose[1], -46]
print('x, y, z', D2)

# Calibration
tiley = (C1[0]-C2[0]) / (D1[1]-D2[1])
tilez = (C1[1]-C2[1]) / (D1[2]-D2[2])
homey = D1[1] - (C1[0]/tiley)
homez = D1[2] - (C1[1]/tilez)
print('The setup is calibrated.')

with open('parameters.csv','w') as f:
    writer = csv.writer(f)
    writer.writerow([tiley,tilez,homey,homez])
print('Parameters stored.')