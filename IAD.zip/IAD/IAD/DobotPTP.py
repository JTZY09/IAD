import DobotDllType as dType
import pandas as pd
import numpy as np

api = dType.load()
dType.DisconnectDobot(api)
dType.ConnectDobot(api, "COM3", 115200)
#dType.SetQueuedCmdForceStopExec(api)
#dType.SetQueuedCmdStopExec(api)
dType.SetQueuedCmdClear(api)

print(f"Move a cube from (289,-56) to (285,33)")
current_pose = dType.GetPose(api)
print(f"current position: {current_pose}")
dType.SetQueuedCmdClear(api)
dType.SetQueuedCmdStartExec(api)
i = 0
end_height = -40

while i<6:
    # Above Pick
    dType.SetPTPCmdEx(api, 2, 289, (-56), (60), current_pose[3], 1)
    print(f"Above Pick")

    # Pick
    dType.SetPTPCmdEx(api, 2, 289, -56, -40, current_pose[3], 1)
    print(f"Picking")
    dType.SetEndEffectorSuctionCupEx(api, 1, 1)
    print("Suction enabled")
    dType.dSleep(1000)
    # Above Pick
    dType.SetPTPCmdEx(api, 2, 288, -56, 60, current_pose[3], 1)
    print(f"Above Pick")
    # Above Place
    dType.SetPTPCmdEx(api, 2, 285, 33,  60, current_pose[3], 1)
    print(f"Above Place")
    # Place
    dType.SetPTPCmdEx(api, 2, 285, 33, end_height, current_pose[3], 1)
    print(f"Placing")
    end_height += 20
    dType.SetEndEffectorSuctionCupEx(api, 0, 1)
    print('Suction disabled')
    dType.dSleep(1000)
    # Above Place
    dType.SetPTPCmdEx(api, 2, 285, 33,  60, current_pose[3], 1)
    print(f"Above Place")
    print('\n')
    i +=1 

inpu = input('Press enter to end.')
dType.SetEndEffectorSuctionCupEx(api, 0, 0) 