from PIL import Image
import matplotlib.pyplot as plt

# Load and display the image
image_path = "boxes.jpg"
image = Image.open(image_path)

plt.imshow(image)
plt.axis("off")  # Turn off axis numbers and ticks
plt.show()
