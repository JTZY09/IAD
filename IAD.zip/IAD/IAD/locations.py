import DobotDllType as dType

def calibrate_location():
    api = dType.load()
    dType.DisconnectDobot(api)
    dType.ConnectDobot(api, "COM3", 115200)
    #dType.SetQueuedCmdForceStopExec(api)
    #dType.SetQueuedCmdStopExec(api)
    dType.SetQueuedCmdClear(api)

    current_pose = dType.GetPose(api)

    actual_positions = {
        'L1': (),
        'L2': (),
        'L3': (),
        'L4': (),
        'L5': ()
    }

    for position in actual_positions.keys():
        print(f"Place the dobot on the cube at {position}.")
        input("Enter when done.")
        current_pose = dType.GetPose(api)
        print(f"Dobot coords at {position}: {current_pose[0], current_pose[1], current_pose[2]}\n")

        actual_positions[position] = (current_pose[0], current_pose[1])

    return actual_positions

# Example Output
# actual_positions = calibrate_location()
# print("Coordinates of each position of the mechanical arm:\n", actual_positions)