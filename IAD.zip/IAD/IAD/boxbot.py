from IAD.locations import calibrate_location
from camera import capture
from keras.models import load_model
from drecognizer import prediction
from IAD.calibration2 import calibrate_with_custom_coords
from boxSorter import box_sorting_process
from translation import translate
from picknplace import pick_n_place

image = "boxes_.jpg"
model = load_model('mnist_digit_model.h5')
api_key = "sk-proj-cUvQC7boOawIfjn1sD8J9T3BlbkFJpjQbvm47igbN5F8iu5kr"

while True:
    print("Box Bot Execution")
    print("1. Pick N Place")
    print("2. Debugger")
    print("3. Quit")
    mainOption = input("Select: ")

    if mainOption == "1":
        homeCheck = input("Make sure u already done the homing of the dobot in the dobot studio.(y/n) ")

        if homeCheck == "y":
            print("\nNow, perform the location calibration for A to E.")
            loCaCheck = input("Already done this before? (y/n) ")

            if loCaCheck == "n":
                print("Put the cubes on L1 (A) to L5 (B) -- only one cube for each location.")
                input("Press enter if done.")
                actual_positions = calibrate_location()

            inpu = input("Use demo image? (y/n) ")
            if inpu == "y":
                image = "boxes_demo.jpg"
                print("Current image: ", image)
            else:
                print("\nNow prepare to launch the droidcam for capturing image.")
                input("Press enter if done.")
                print("Press 's' for capture, 'q' for quit.")
                capture()
                image = "boxes.jpg"
                print("Current image: ", image)

            print("\nNow launching the digit recognizer to detect digit cubes' locations.")
            digit_locations = prediction(image, model)
            
            print("\nNow perform calibration to calculate ratios for converting pixel coords to robot coords.")
            calibrate_with_custom_coords()

            print("\nNow launching chatgpt to produce commands for arranging the cubes.")
            commands_list = box_sorting_process(image, api_key)
            commands = [(str(item[0]), str(item[1])) for item in commands_list]

            print("\nNow translating the commands with digit locations.")
            translated_commands = translate(digit_locations, commands, actual_positions)

            print("\nDobot is ready to pick n place the cubes.")
            input("Press enter to start.")
            pick_n_place(translated_commands)

            input("Press enter to return to main option.")

        else:
            print("This program is terminated. Pls do the homing in the dobot studio.")
            break

    elif mainOption == "2":
        while True:
            print("\n1. Location calibration")
            print("2. Digit recognition")
            print("3. Box 2 GPT")
            print("4. Command translation")
            print("5. Pick n place\n")
            debugOption = input("Select or Return (q): ")
        
            if debugOption == "1":
                print("Put the cubes on L1 (A) to L5 (B) -- only one cube for each location.")
                input("Press enter if done.")
                actual_positions_debug = calibrate_location()
                print("Coordinates of each position of the mechanical arm:\n", actual_positions_debug)
            
            elif debugOption == "2":
                inpu = input("Want to capture new image for testing? (y/n)")
                if inpu == "y":
                     capture()
                digit_locations_debug = prediction(image, model)
                print(digit_locations_debug)

            elif debugOption == "3":
                inpu = input("Want to capture new image for testing? (y/n)")
                if inpu == "y":
                    capture()
                commands_debug = box_sorting_process(image, api_key)
                print("Chatgpt arrangements: ", commands_debug)

            elif debugOption == "4":
                translated_commands_debug = translate(digit_locations, commands, actual_positions)
                print(translated_commands_debug)

            elif debugOption == "5":
                pick_n_place(translated_commands)

            else:
                print("Return.")
                break

    elif mainOption == "3":
        print("Closing this program.")
        break

    else:
        print("Pls type correctly.")
