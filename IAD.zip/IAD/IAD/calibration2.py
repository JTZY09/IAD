import DobotDllType as dType
import csv

# Dobot connection setup
api = dType.load()
dType.ConnectDobot(api, "COM3", 115200)[0]
dType.SetQueuedCmdClear(api)

def get_robot_pose():
    """Retrieve the current pose of the Dobot arm."""
    current_pose = dType.GetPose(api)
    return [current_pose[0], current_pose[1], current_pose[2]]

def parse_coords_input(prompt):
    """Parse user input into a tuple of integers for coordinates."""
    user_input = input(prompt)
    # Remove any spaces and split by comma
    coords = user_input.replace(" ", "").split(",")
    # Convert to tuple of integers
    return (int(coords[0]), int(coords[1]))

def calibrate_with_custom_coords():
    """
    Calibrate Dobot arm using custom pixel coordinates for C1 and C2
    based on user input for specific location and cube index.
    """
    # Step 1: Get pixel coordinates for C1 from user
    print("Enter pixel coordinates for C1 (L2 second cube).")
    C1 = parse_coords_input("Enter C1 pixel coordinates as 'x, y': ")
    input("Move Dobot to C1 and press Enter when done.")
    D1 = get_robot_pose()[:2] + [-26]  # Store x, y, with z fixed at -26
    print(f"C1 pixel coords: {C1}, D1 robot coords: {D1}")

    # Step 2: Get pixel coordinates for C2 from user
    print("Enter pixel coordinates for C2 (e.g., L3 first cube):")
    C2 = parse_coords_input("Enter C2 pixel coordinates as 'x, y': ")
    input("Move Dobot to C2 and press Enter when done.")
    D2 = get_robot_pose()[:2] + [-46]  # Store x, y, with z fixed at -46
    print(f"C2 pixel coords: {C2}, D2 robot coords: {D2}")

    # Step 3: Perform calibration calculations
    tiley = (C1[0] - C2[0]) / (D1[1] - D2[1])
    tilez = (C1[1] - C2[1]) / (D1[2] - D2[2])
    homey = D1[1] - (C1[0] / tiley)
    homez = D1[2] - (C1[1] / tilez)

    print("Calibration completed with calculated parameters.")
    print(f"tiley: {tiley}, tilez: {tilez}, homey: {homey}, homez: {homez}")

    # Step 4: Save parameters to CSV
    with open('parameters.csv', 'w') as f:
        writer = csv.writer(f)
        writer.writerow([tiley, tilez, homey, homez])
    print("Parameters saved to 'parameters.csv'.")

# Example usage
# calibrate_with_custom_coords()
