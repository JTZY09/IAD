import DobotDllType as dType
import pandas as pd
import numpy as np

print('Make sure the setup is calibrated.')
print('Put the object in designated region.')
print("Put the robot arm away so that's not obstructing the view.")
input('Enter when done')

api = dType.load()
dType.DisconnectDobot(api)
dType.ConnectDobot(api, "COM3", 115200)
#dType.SetQueuedCmdForceStopExec(api)
#dType.SetQueuedCmdStopExec(api)
dType.SetQueuedCmdClear(api)

current_pose = dType.GetPose(api)
print(f"Current position: {current_pose}")
       
inpu = input('Press enter to end.')
dType.SetEndEffectorSuctionCupEx(api, 0, 0)