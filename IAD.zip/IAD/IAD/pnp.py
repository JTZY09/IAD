import DobotDllType as dType
import pandas as pd
import numpy as np
from translation import translate
from keras.models import load_model
from drecognizer import prediction


# Calibration setup
param = pd.read_csv('parameters.csv', header=None)
tiley,tilez,homey,homez=param.iloc[0]

print('Make sure the setup is calibrated.')
print('Put the object in designated region.')
print("Put the robot arm away so that's not obstructing the view.")
input('Enter when done')

api = dType.load()
dType.DisconnectDobot(api)
dType.ConnectDobot(api, "COM3", 115200)
#dType.SetQueuedCmdForceStopExec(api)
#dType.SetQueuedCmdStopExec(api)
dType.SetQueuedCmdClear(api)

# Load your trained model
# Model path - ensure correct path and file format
model_path = load_model('mnist_digit_model.h5')  # Correct path and format
image = "boxes.jpg"

while True:
    #detected_digits = {'1': (69, 307), '2': (408, 417), '6': (241, 205), '4': (68, 417), '5': (240, 417), '3': (242, 307)}
    detected_digits = prediction(image, model_path)
    #commands = [(6, 'L4'), (5, 'L5'), (3, 2), (4, 3), (5, 4), (6, 5)]
    inpu = input("Enter chatgpt commands: ")
    parsed_list = eval(inpu)
    commands = [(str(item[0]), str(item[1])) for item in parsed_list]

    translated_commands = translate(detected_digits,commands,tiley,tilez,homey,homez)

    for command in translated_commands:
        digit, current_pos, new_pos = command
        current_x, current_y, current_z = int(current_pos[0]), int(current_pos[1]), int(current_pos[2])
        new_x, new_y, new_z = int(new_pos[0]), int(new_pos[1]), int(new_pos[2])
        print(f"Move digit '{digit}' from ({current_x},{current_y},{current_z}) to ({new_x},{new_y},{new_z})")
        dType.SetQueuedCmdClear(api)
        current_pose = dType.GetPose(api)
        
        # Start execution
        dType.SetQueuedCmdStartExec(api)
        dType.SetPTPCommonParamsEx(api,75,75,1)  # Speed of dobot

        # Home
        dType.SetPTPCmdEx(api, 2, 198, 8, 123, current_pose[3], 1)
        print(f"Back to Home: 198, 8, 123")

        # Above Pick
        dType.SetPTPCmdEx(api, 2, current_x, current_y, 65, current_pose[3], 1)
        print(f"Above Pick: {current_x}, {current_y}, 65")

        # Picking
        dType.SetPTPCmdEx(api, 2, current_x,  current_y,  current_z, current_pose[3], 1)
        print(f"Picking: {current_x}, {current_y}, {current_z}")
        dType.SetEndEffectorSuctionCupEx(api, 1, 1)
        print("Suction enabled")
        dType.dSleep(1000)

        # Above Pick
        dType.SetPTPCmdEx(api, 2, current_x,  current_y, 65, current_pose[3], 1)
        print(f"Above Pick: {current_x}, {current_y}, 65")

        # Above Place
        dType.SetPTPCmdEx(api, 2, new_x,  new_y,  65, current_pose[3], 1)
        print(f"Above Place: {new_x}, {new_y}, 65")

        # Placing
        dType.SetPTPCmdEx(api, 2, new_x,  new_y,  new_z, current_pose[3], 1)
        print(f"Placing: {new_x}, {new_y}, {new_z}")
        dType.SetEndEffectorSuctionCupEx(api, 0, 1)
        print('Suction disabled')
        dType.dSleep(1000)

        # Above Place
        dType.SetPTPCmdEx(api, 2, new_x,  new_y,  65, current_pose[3], 1)
        print(f"Above Place: {new_x}, {new_y}, 65")
        print('\n')

    end = input('Press enter to end.')
    dType.SetEndEffectorSuctionCupEx(api, 0, 0)
    break
