import cv2

def detect_square():
    cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    cap.set(3, 960)  # Set camera resolution width
    cap.set(4, 480)  # Set camera resolution height
    print('Camera connected')
    
    coordinates = None  # Variable to store coordinates of detected square's center

    while True:
        ret, frame = cap.read()

        if ret:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)  # Apply Gaussian blur to remove noise
            edges = cv2.Canny(blurred, 50, 150)  # Canny edge detection

            # Find contours
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for contour in contours:
                # Approximate the contour
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)

                # If the contour has 4 vertices, it could be a rectangle or square
                if len(approx) == 4:
                    x, y, w, h = cv2.boundingRect(approx)
                    aspect_ratio = float(w) / h

                    # Check if it's a square (aspect ratio close to 1)
                    if 0.95 <= aspect_ratio <= 1.05:
                        # Calculate the center of the square
                        cx = x + w // 2
                        cy = y + h // 2
                        coordinates = (cx, cy)

                        # Draw the square and its center
                        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 255), 2)
                        cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
                        cv2.putText(frame, f"({cx}, {cy})", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            # Show the images
            cv2.imshow("Edges", edges)
            cv2.imshow("Frame", frame)

            # Press 's' key to save coordinates and exit, or 'q' to quit without saving
            key = cv2.waitKey(1) & 0xFF
            if key == ord('s'):  # Save and exit
                break
            elif key == ord('q'):  # Exit without saving
                coordinates = None
                break

        else:
            print('Failed to grab frame.')
            return None

    cap.release()
    cv2.destroyAllWindows()
    return coordinates

# Run the function
coords = detect_square()
if coords:
    print("Detected square center coordinates:", coords)
else:
    print("No square detected or exited without saving.")