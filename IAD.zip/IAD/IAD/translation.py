import pandas as pd

#Read the parameters
param = pd.read_csv('parameters.csv', header=None)
tiley, tilez, homey, homez = param.iloc[0]
#tiley, tilez, homey, homez = 4.724, -4.1, -100.877, 62.195
                        
def translate(digit_results, commands, tiley, tilez, homey, homez):
    tolerance = 10  # Fault tolerance
    translated_commands = []  
    current_heights = {}  # The current height of each y position
    actual_positions = {'L1': (233, -34),
                    'L2': (230, -13),
                    'L3': (229, 12),
                    'L4': (226, 34),
                    'L5': (226, 58)}

    for block, (img_x, img_y) in digit_results.items():
        # Pixel to Robot coordinates
        robot_y = img_x / tiley + homey
        robot_z = img_y / tilez + homez 

        # Find the relative positions in robot coordinates to the pixel
        for pos_name, (actual_x, actual_y) in actual_positions.items():
            if abs(robot_y - actual_y) <= tolerance:
                if -66 <= robot_z <= -40:
                    actual_z = -46
                elif -40 < robot_z <= -20:
                    actual_z = -26
                elif -20 < robot_z <= -5:
                    actual_z = -6

                digit_results[block] = (actual_x, actual_y, actual_z)
                if actual_y not in current_heights or robot_z > current_heights[actual_y]:
                    current_heights[actual_y] = robot_z
                    break
            
    for current, destination in commands:
        current_block_pos = digit_results[current]
        
        # If destination is in actual_positions, use its coordinates directly
        if destination in actual_positions:
            destination_x, destination_y = actual_positions[destination]
        else:
            # Otherwise get the coordinates of destination from digit_results
            destination_x, destination_y = digit_results[destination][:2]
        
        # Update the height information of the target location
        destination_z = current_heights.get(destination_y, -66)
        new_block_pos = (destination_x, destination_y, destination_z + 20)
        
        translated_commands.append((current, current_block_pos, new_block_pos))

        # Update block position and height information
        digit_results[current] = new_block_pos
        current_heights[destination_y] = destination_z + 20
        
        # Update the height of the previous position
        prev_y = current_block_pos[1]
        current_heights[prev_y] = current_heights.get(prev_y, -46) - 20
    
    return translated_commands

#Testing
# digit_results = {'1': (356, 309), '2': (263, 363), '3': (355, 368), '4': (157, 300), '5': (260, 299), '6': (159, 362)}
# commands = [('1', 'L4'), ('5', 'L5'), ('2', '1'), ('3', '2'), ('4', '3'), ('5', '4'), ('6', '5')]

# translated_commands = translate(digit_results, commands, tiley, tilez, homey, homez)
# print(translated_commands)