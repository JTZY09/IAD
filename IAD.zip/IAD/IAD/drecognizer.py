import cv2
import numpy as np
from keras.models import load_model

# Load the pre-trained model
model = load_model('mnist_digit_model.h5')

def prediction(image_path, model):
    # Load the image
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Could not read the image at {image_path}.")
        return {}

    # Convert to HSV color space and threshold for blue color
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    lower_hsv = np.array([100, 150, 0])
    upper_hsv = np.array([140, 255, 255])
    mask = cv2.inRange(hsv, lower_hsv, upper_hsv)

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(mask, (5, 5), 0)
    binary = blurred

    # Use morphological dilation to refine digit contours
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    dilated = cv2.dilate(binary, kernel, iterations=1)

    # Find contours
    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Dictionary to store digit and their center coordinates
    digit_locations = {}

    for contour in contours:
        area = cv2.contourArea(contour)
        if area > 100:  # Filter small contours by area
            x, y, w, h = cv2.boundingRect(contour)

            # Calculate the center of the bounding box
            cx = x + w // 2
            cy = y + h // 2

            # Extract and preprocess the ROI for digit prediction
            roi = dilated[y:y + h, x:x + w]
            roi_resized = cv2.resize(roi, (20, 20), interpolation=cv2.INTER_AREA)
            roi_padded = cv2.copyMakeBorder(roi_resized, 4, 4, 4, 4, cv2.BORDER_CONSTANT, value=0)

            # Prepare for model prediction
            roi_processed = roi_padded.reshape(1, 28, 28, 1).astype('float32') / 255.0

            # Predict the digit
            prediction = model.predict(roi_processed)
            class_index = np.argmax(prediction)
            confidence = np.max(prediction)

            # Draw bounding box and center on the image
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.circle(image, (cx, cy), 5, (0, 0, 255), -1)  # Red dot at the center
            cv2.putText(image, f"{class_index} ({confidence*100:.1f}%)", (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            # Add the detected digit and its center to the dictionary
            digit_locations[str(class_index)] = (cx, cy)
            print(f"Detected Digit: {class_index} with confidence {confidence*100:.1f}% at center ({cx}, {cy})")

    # Show the final image with bounding boxes and predictions
    cv2.imshow("Detected Digits", image)
    cv2.waitKey(0)  # Wait until a key is pressed to close the image window
    cv2.destroyAllWindows()

    # Return the dictionary with digit locations
    return digit_locations

# Example usage
image_path = "boxes.jpg"  # Replace with your image path
digit_locations = prediction(image_path, model)
print(digit_locations)


